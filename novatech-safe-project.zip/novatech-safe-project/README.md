# NovaTech Safe Project

Projet demo sécurisé pour étudiants, utilisant Local JSON file au lieu de Azure Table Storage.

Login Admin:
- username: admin
- password: 1234

Run locally:
npm install
npm start

Puis ouvrir http://localhost:3000
